#ifndef CRC_H_
#define CRC_H_

/*
 * Functions
 */
unsigned short crc16(unsigned char *buf, unsigned int len);

#endif /* CRC_H_ */
