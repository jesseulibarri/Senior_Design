/********************************************************
 * File Name: pirate.h
 *
 *
 * *****************************************************/

#ifndef PIRATE_H
#define PIRATE_H

void pirate_mode();

#endif
