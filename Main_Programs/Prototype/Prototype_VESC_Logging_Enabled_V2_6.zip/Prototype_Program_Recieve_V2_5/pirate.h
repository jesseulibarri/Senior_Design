/*******************************************************
 * File Name: pirate.h
 * Authors: Jesse Ulibarri, Shane Licari, Eli Yazzolino
 * Date: 4/20/2017
 *
 * Description:
********************************************************/

#ifndef PIRATE_H
#define PIRATE_H

void pirate_mode();

#endif
